package com.project.common;

public class Constants {
	
	// 사용자 이미지 첨부파일을 저장할 경로
	private static final String UPLOAD_IMAGES_PATH = "D:/MemberMgmt";

	public static String getUploadImagesPath() {
		return UPLOAD_IMAGES_PATH;
	}
	
}
